#include "io_internal.h"

void io_check() {
  io_waituntil2(0);
}
